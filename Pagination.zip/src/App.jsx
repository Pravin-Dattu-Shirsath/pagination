import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Pagination from './Component/Pagination'

function App() {
  return (
    <main>
<Pagination/>
    </main>
  );
}

export default App;